function reducer(state, action) {

}

export default reducer;
