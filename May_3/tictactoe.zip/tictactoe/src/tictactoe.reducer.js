const INITIAL_STATE = {
  currentPlayer: X,
  board: ['', '', '','', '', '', '', '','']
}
